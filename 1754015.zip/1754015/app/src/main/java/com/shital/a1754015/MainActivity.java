package com.shital.a1754015;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    Button b1, b2;
    EditText e1, e2, e3, e4, e5;
    Spinner sp;
    String spn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = findViewById(R.id.button);
        b2 = findViewById(R.id.button2);
        e1 = findViewById(R.id.editText);
        e2 = findViewById(R.id.editText2);
        e3 = findViewById(R.id.editText3);
        e4 = findViewById(R.id.editText4);
        e5 = findViewById(R.id.editText5);
        sp = findViewById(R.id.spinner);

        ArrayAdapter aa = ArrayAdapter.createFromResource(this, R.array.str_arr, android.R.layout.simple_spinner_item);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(aa);

        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                spn=parent.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (e2.getText().toString().equals(e3.getText().toString()))
                {
                    if (spn.equals("User")) {
                        Toast.makeText(getApplicationContext(),"hello",Toast.LENGTH_LONG).show();
                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference myRef = database.getReference();
                        String key = database.getReference("jobs").push().getKey();
                        myRef.child("users").child(key).setValue(new Mydata(e1.getText().toString(), e2.getText().toString(), e4.getText().toString(), e5.getText().toString()));

                    }
                    if (spn.equals("ambulance_driver")) {
                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference myRef = database.getReference();
                        String key = database.getReference("jobs").push().getKey();
                        myRef.child("driver").child(key).setValue(new Mydata(e1.getText().toString(), e2.getText().toString(), e4.getText().toString(), e5.getText().toString()));
                    }
                    if (spn.equals("Medical_technician")) {
                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference myRef = database.getReference();
                        String key = database.getReference("jobs").push().getKey();
                        myRef.child("technician").child(key).setValue(new Mydata(e1.getText().toString(), e2.getText().toString(), e4.getText().toString(), e5.getText().toString()));
                    }
                    if (spn.equals("hospital_Administrative")) {
                        FirebaseDatabase database = FirebaseDatabase.getInstance();
                        DatabaseReference myRef = database.getReference();
                        String key = database.getReference("jobs").push().getKey();
                        myRef.child("HAP").child(key).setValue(new Mydata(e1.getText().toString(), e2.getText().toString(), e4.getText().toString(), e5.getText().toString()));
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "password not match", Toast.LENGTH_LONG).show();
                }

            }


        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,login.class);
                startActivity(i);
            }
        });


    }
}

class Mydata
{
 public String email,password,mobileno,city;

 Mydata(String email,String password,String mobileno,String city){
     this.city=city;
     this.email=email;
     this.mobileno=mobileno;
     this.password=password;
 }
}




