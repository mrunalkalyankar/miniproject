package com.shital.a1754015;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class login extends AppCompatActivity
{
    Spinner sp;
    String spn;
    Button b1;
    EditText e1,e2;
    int position;
    ArrayList<String> ar=new ArrayList<>();
    String s1,s2;
    String email,pass;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        b1=findViewById(R.id.button3);
        e1=findViewById(R.id.editText6);
        e2=findViewById(R.id.editText7);
        sp=findViewById(R.id.spinner2);

        ArrayAdapter aa=ArrayAdapter.createFromResource(this,R.array.str_arr,android.R.layout.simple_spinner_item);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(aa);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                spn=parent.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        b1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (spn.equals("User"))
                {
                    FirebaseDatabase.getInstance().getReference().child("users").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot)
                        {
                            for(DataSnapshot snapshot:dataSnapshot.getChildren())
                            {
                                email=snapshot.child("email").getValue().toString();
                                pass=snapshot.child("password").getValue().toString();

                            }
                            if(email.equals(e1.getText().toString())&&pass.equals(e2.getText().toString()))
                            {

                                Intent i=new Intent(getApplicationContext(), map.class);
                                Bundle b=new Bundle();
                                b.putString("em",e1.getText().toString());
                                b.putString("type",spn);
                                i.putExtras(b);
                                startActivity(i);
                                Toast.makeText(getApplicationContext(),"Login success" ,Toast.LENGTH_LONG).show();
                            }

                            else
                            {
                                Toast.makeText(getApplicationContext(),"Invalid login" ,Toast.LENGTH_LONG).show();
                            }

                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });

                }
                if (spn.equals("ambulance_driver"))
                {
                    FirebaseDatabase.getInstance().getReference().child("driver").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot)
                        {
                            for(DataSnapshot snapshot:dataSnapshot.getChildren())
                            {
                                email=snapshot.child("email").getValue().toString();
                                pass=snapshot.child("password").getValue().toString();

                            }
                            if(email.equals(e1.getText().toString())&&pass.equals(e2.getText().toString()))
                            {

                                Intent i=new Intent(getApplicationContext(),map.class);
                                Bundle b=new Bundle();
                                b.putString("em",e1.getText().toString());
                                b.putString("type",spn);
                                i.putExtras(b);
                                startActivity(i);
                                Toast.makeText(getApplicationContext(),"Login success" ,Toast.LENGTH_LONG).show();
                            }
                            else
                            {
                                Toast.makeText(getApplicationContext(),"Invalid login" ,Toast.LENGTH_LONG).show();
                            }

                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });

                }
                if (spn.equals("Medical_technician"))
                {
                    FirebaseDatabase.getInstance().getReference().child("technician").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot)
                        {
                            for(DataSnapshot snapshot:dataSnapshot.getChildren())
                            {
                                email=snapshot.child("email").getValue().toString();
                                pass=snapshot.child("password").getValue().toString();

                            }
                            if(email.equals(e1.getText().toString())&&pass.equals(e2.getText().toString()))
                            {

                                Intent i=new Intent(getApplicationContext(),map.class);
                                Bundle b=new Bundle();
                                b.putString("em",e1.getText().toString());
                                b.putString("type",spn);
                                i.putExtras(b);
                                startActivity(i);
                                Toast.makeText(getApplicationContext(),"Login success" ,Toast.LENGTH_LONG).show();
                            }
                            else
                            {
                                Toast.makeText(getApplicationContext(),"Invalid login" ,Toast.LENGTH_LONG).show();
                            }

                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });

                }
                if (spn.equals("hospital_Administrative"))
                {
                    FirebaseDatabase.getInstance().getReference().child("HAP").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot)
                        {
                            for(DataSnapshot snapshot:dataSnapshot.getChildren())
                            {
                                email=snapshot.child("email").getValue().toString();
                                pass=snapshot.child("password").getValue().toString();

                            }

                            if(email.equals(e1.getText().toString())&&pass.equals(e2.getText().toString()))
                            {

                                Intent i=new Intent(getApplicationContext(),map.class);
                                Bundle b=new Bundle();
                                b.putString("em",e1.getText().toString());
                                b.putString("type",spn);
                                i.putExtras(b);
                                startActivity(i);
                                Toast.makeText(getApplicationContext(),"Login success" ,Toast.LENGTH_LONG).show();
                            }
                            else
                            {
                                Toast.makeText(getApplicationContext(),"Invalid login" ,Toast.LENGTH_LONG).show();
                            }

                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });

                }

            }
        });

    }
}
