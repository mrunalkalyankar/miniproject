package com.example.fireauth;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class h_status extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_h_status);
    }
}
