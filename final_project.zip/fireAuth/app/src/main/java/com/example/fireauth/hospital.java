package com.example.fireauth;

import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.util.List;
import java.util.logging.Handler;
import java.util.logging.LogRecord;


public class hospital extends AppCompatActivity
{
    EditText em,add;
    TextView ts;
    String email,addr,l1;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital);
        em=findViewById(R.id.editText4);
        add=findViewById(R.id.editText3);
        ts=findViewById(R.id.textView4);
        b1=findViewById(R.id.button3);

        email=em.getText().toString();
        addr=add.getText().toString();

        ts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(hospital.this,h_status.class);
                i.putExtra("em",email);
                startActivity(i);

            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"hiiiiii",Toast.LENGTH_LONG).show();
               LatLng ln=getLocationFromAddress(hospital.this,addr);
                double lat = ln.latitude;
                double lng = ln.longitude;
               // Toast.makeText(getApplicationContext(),lat+" "+lng,Toast.LENGTH_LONG).show();



                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference();
                myRef.child("host_loc").child(email).child("latitude").setValue(lat);
                myRef.child("host_loc").child(email).child("longitude").setValue(lng);

            }
        });
    }

    public LatLng getLocationFromAddress(Context context, String strAddress)
    {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }

            Address location = address.get(0);
            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return p1;
    }


}
