package com.example.fireauth;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class driver extends AppCompatActivity {
    EditText em, ph;
    TextView ts1;
    String email, phn;
    Button b1;
    double latitude, longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver);
        em = findViewById(R.id.editText7);
        ph = findViewById(R.id.editText6);
        ts1 = findViewById(R.id.textView6);
        b1 = findViewById(R.id.button4);

        email = em.getText().toString();
        phn = ph.getText().toString();

        ts1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(driver.this, h_status.class);
                //i.putExtra("em",email);
                startActivity(i);
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


            }
        });


    }
}
